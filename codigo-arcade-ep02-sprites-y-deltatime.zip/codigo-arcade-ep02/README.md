# Episodio #02 — Sprites Animados y Delta Time (`dt`)

Proyecto oficial del canal **Código Arcade** (`codigoarcade-dev.blogspot.com`).

## Archivos incluidos
- `index.html`: Estructura principal y lienzo `<canvas>` de `800x400`.
- `style.css`: Estilos oscuros estilo arcade con `image-rendering: pixelated`.
- `game.js`: Bucle principal con `requestAnimationFrame`, física gobernada por **Delta Time (`dt`)** y recorte de celdas con `ctx.drawImage()`.
- `spritesheet.png`: Hoja de sprites original de `128x128 px` dividida en cuadrícula exacta de `32x32 px`.

## Mapa de la Cuadrícula (`spritesheet.png`)
| Fila | Acción | Coordenada `sy` | Fotogramas (`sx = col * 32`) |
| :--- | :--- | :--- | :--- |
| **Fila 0** | Idle (Reposo) | `0 px` | Columnas 0 y 1 |
| **Fila 1** | Run (Correr) | `32 px` | Columnas 0, 1, 2 y 3 |
| **Fila 2** | Jump & Fall | `64 px` | Columna 0 (subir), Columna 1 (caer) |
| **Fila 3** | Sierra Eléctrica | `96 px` | Columnas 0 y 1 |

## Reto del Episodio
Abre `spritesheet.png` en tu editor Pixel Art favorito (como **Piskel** o **Aseprite**) y reemplaza los dibujos del corredor y la sierra por tus propios personajes respetando cada celda de `32x32 px`.
