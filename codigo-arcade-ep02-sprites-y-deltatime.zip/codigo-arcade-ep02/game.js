// ============================================================================
// CÓDIGO ARCADE — EPISODIO #02: SPRITES ANIMADOS Y DELTA TIME (dt)
// ============================================================================
// Puedes editar 'spritesheet.png' con cualquier editor Pixel Art (Piskel,
// Aseprite, GIMP) respetando la cuadrícula de 128x128 px (celdas de 32x32 px):
//   - Fila 0 (sy = 0):  Idle / Reposo (2 frames: col 0, 1)
//   - Fila 1 (sy = 32): Run / Correr  (4 frames: col 0, 1, 2, 3)
//   - Fila 2 (sy = 64): Jump & Fall   (2 frames: col 0 subiendo, col 1 cayendo)
//   - Fila 3 (sy = 96): Sierra        (2 frames: col 0, 1)
// ============================================================================

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// 1. CARGA DEL SPRITE SHEET (128x128 px)
const spriteSheet = new Image();
spriteSheet.src = 'spritesheet.png';

// Respaldo automático por si abres index.html directamente sin servidor local
spriteSheet.onerror = () => {
  spriteSheet.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAGc0lEQVR4nO2dMWxcNRjHfRQSDvVoVemOTpWKBMxEgEKXqmUgGwOgLqhzUSUkhigDA+rQATFE6tK9ylIVhm5h6NCFVFAdcxaQsgCJhCipSBOGx1Jf/Hx+9mc/+9l+/v+kSHf3Lu/zs//+bH/vfT7GAADAiaPH4+ro8biKXQ7gzguxC9AGCLA9L1K+NBxNlJV86pL++MH+7sC1YKAbSA00HE2qw7X7Vide/OYjbwJoEpgJCNAMyQNw3nv/bdL3ftr6xakwOlwECMxYCSA2MQXYV5wEsHV5UXv8xJZTWUAErAQw61mXlxljjL3y6muMMcb+/efP2uvQQID+yGoISEWAfSLrOABoTysPIPY29Lw8cRLAiZuPfJfDCQiwPUoBPL14tRZ4GU83uykNkVQE2AfIHgCBlX5SC5X+9+XNuZDr4XSbMWbvBVzCsE32XT0QQsFmtB7g97Xrx2/eeJMdffYt6aQLG6ts54+/Z4157uzpVg2xt7TSiQBLxHkV8O4nV2rvf/7ubuvCyKQiwD5TE8BL61/VKmpn7Xqn99q5fXkSqqILAZZAkpHAkw/vDBhjbIfdwsMegXEWAHpcP9AKQBw7bR/KCD3uQoB+sPIACxurocqhJGUB9gWrSvrw089rjfDDvdsD3ec+sRUAloE0kpwEqjjY3x3EFGBfwe3gwoEACoc8BCw/eFY9kT+8d5sxxtiTa+v1715brx598DLccAZkMweAAMNAFoCuQlHZAAAAQFnETs+G/fb2EQcoHHJ6uMvJ+5Ie3mf75GVg7PRs2A9jP5v9AWA/jH3MAQony/0BYN+f/az2B4B9//YxBBQOBFA4We8PAPvt7We5PwDs+7Of5f4AoSnp+pWhQl8VYBsKTSU9vKTrr3mApgLETs/uyn6J10+aA/x19xbbfv76/A19TPq3r2cx6Kptdk6s9HDR7pkrX8xe29jn+CpHqOs3CuDkwzsDVZZuiPTsFNPDeaayfEeuL9ev3R8gFrHSw/n1d70vgkyX149AUOFkuz8A7PuxTxLAubOnB8PRpKJMQs7fuM8WNla9zIJjpYf7TC33VY5Q108uXOz0bNgPY9/4JdvU65Cp2imlh6dks01ZMAksHAigcCCAwtGOFcsPns1NPEyZwC7/Q0F33lA2bcoSw6aP64cHAAAA4ELs7FjQHswBCieL7OAmuPdZeGcvidvYOZJNdjAIQxbZwU0e6NQl/XHsF2wmm30C4YHCkFV2cOz8/D6SVXYw8E82Q4BI7Pz8PpGVAOCB/JN1djBoT5bZwcAfWQ0BMvBA7SElh46nm0mtq+GB/EHyAF1nx5aUnx8bpQBSyY4VSckD9QllciglOTJEdmyq+fl9hpQezpj7LWEfxNqfoASSXwV0uT9BiSSVHZzK/gQloRRAKtmxIDxJ/3q4Drh8P5B6JzX7NGTGLHV/AsaYt/0JSiD5SaBISh6oL2QjALFHy56Gg5+Ntwd5AYVj9AC6H22WwY845wc8QOFk1zubcvM58Dh2wAMAAAAAAAA7Yj4kAvzQehXQlQhs7ECYdJwFMBxNqr2lFZ9lIdn08R1wTGsPsLe00lmlm2zFEGXuNApgOJpUTZUtV7SuYXTncYHbks+JxndD6wHEyrYdg/lfiEbZW1qpiQ6N7442bi5XLH82v6myVcfH000vT+c0NfJ4ujlXHl82S8DqgRBTL4vRC9Hz25HUE0E+5wq6c8E7HGOsiCbXu/jxr3OfHX7/eu29iyumjucU+zIYGuZxWgaqKl/3uQ0H+7sDUx5gSPulYVwGyr3RVMni8aYlWxts7Iug96tRVgjV7VcXtmevBz++VTvWdjigiI9qH43fTM0D2KzdxcpXvZex9QamocDWPlAzEwBvmJDLKjmAY4IyHzCB3q9ntgzklTSebgYTAm9MaoP4iPA931yiggjUzE0CD/Z3B7zn6XqfPObK70X4ufi5KQUzNb6N/S5vWOWGdRyAstTiEzDbHt9kU8TGvgiGAjXWcQBTsEU+7jsQZGufAy+gxupmkAg1EmfT80wNZPJEsudpAp7gGOd7Aaae6IKuYWRxmOyjkWlYDQGmiaHpOEiPRg/A3b/YoOJSUXcPni8lGQu/DFM9DwDoaIcA15mz+D+iGHwirjBUggQ0GocA3ZpdjtDphGKz9qcixxQocQsQgOFoUj29eNXr3T6dLcq9BN93H4GGLisbiSGJgsoGAIBc+R9K/n6CjzpvvwAAAABJRU5ErkJggg==';
};

const CELL_SIZE = 32; // Tamaño de cada celda en la hoja original

// 2. CONSTANTES FÍSICAS EN PÍXELES POR SEGUNDO (INDEPENDIENTES DE LOS FPS)
const GRAVEDAD = 1950;         // px/s²
const FUERZA_SALTO = -720;     // px/s
const VELOCIDAD_JUEGO = 360;   // px/s
const SUELO_Y = 330;           // Coordenada Y del piso

// 3. ESTADO DEL JUGADOR Y MÁQUINA DE ANIMACIÓN
const jugador = {
  x: 110,
  y: SUELO_Y - 64,
  ancho: 64,
  alto: 64,
  velY: 0,
  enElSuelo: true,
  filaEstado: 1,       // 0 = Idle, 1 = Run, 2 = Jump/Fall
  frameActual: 0,      // Columna dentro de la fila
  tiempoAnimacion: 0,  // Acumulador de tiempo en segundos
  intervaloAnim: 0.09  // Cambia de cuadro cada 0.09s (~11 FPS de animación)
};

// 4. OBSTÁCULOS ANIMADOS (SIERRAS)
let obstaculos = [];
let tiempoSpawn = 0;
let proximoSpawn = 1.4;
let sierraFrame = 0;
let sierraTimer = 0;

// 5. ESTADO GENERAL DE LA PARTIDA
let puntaje = 0;
let mejorPuntaje = 0;
let gameOver = false;
let ultimoTiempo = 0;

function reiniciarJuego() {
  jugador.y = SUELO_Y - jugador.alto;
  jugador.velY = 0;
  jugador.enElSuelo = true;
  jugador.filaEstado = 1;
  jugador.frameActual = 0;
  obstaculos = [];
  tiempoSpawn = 0;
  proximoSpawn = 1.3;
  puntaje = 0;
  gameOver = false;
}

function saltar() {
  if (gameOver) {
    reiniciarJuego();
    return;
  }
  if (jugador.enElSuelo) {
    jugador.velY = FUERZA_SALTO;
    jugador.enElSuelo = false;
  }
}

// Controles de teclado, mouse y pantalla táctil
window.addEventListener('keydown', (e) => {
  if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
    e.preventDefault();
    saltar();
  } else if (e.code === 'KeyR' && gameOver) {
    reiniciarJuego();
  }
});
canvas.addEventListener('pointerdown', saltar);

// Colisión AABB con pequeño margen justo para el jugador
function hayColision(a, b) {
  const margen = 12;
  return (
    a.x + margen < b.x + b.ancho - margen &&
    a.x + a.ancho - margen > b.x + margen &&
    a.y + margen < b.y + b.alto - margen &&
    a.y + a.alto - margen > b.y + margen
  );
}

// 6. ACTUALIZACIÓN DE LÓGICA CON DELTA TIME (dt)
function actualizar(dt) {
  if (gameOver) {
    // En Game Over dejamos al personaje en Fila 0 (Idle)
    jugador.filaEstado = 0;
    jugador.tiempoAnimacion += dt;
    if (jugador.tiempoAnimacion >= 0.25) {
      jugador.tiempoAnimacion = 0;
      jugador.frameActual = (jugador.frameActual + 1) % 2;
    }
    return;
  }

  // Física vertical del jugador
  jugador.velY += GRAVEDAD * dt;
  jugador.y += jugador.velY * dt;

  if (jugador.y >= SUELO_Y - jugador.alto) {
    jugador.y = SUELO_Y - jugador.alto;
    jugador.velY = 0;
    jugador.enElSuelo = true;
  }

  // Selector de fila de animación según estado físico
  if (!jugador.enElSuelo) {
    jugador.filaEstado = 2; // Fila 2: Saltar / Caer
    jugador.frameActual = jugador.velY < 0 ? 0 : 1;
  } else {
    jugador.filaEstado = 1; // Fila 1: Corriendo
    jugador.tiempoAnimacion += dt;
    if (jugador.tiempoAnimacion >= jugador.intervaloAnim) {
      jugador.tiempoAnimacion = 0;
      jugador.frameActual = (jugador.frameActual + 1) % 4;
    }
  }

  // Animación de las sierras (Fila 3)
  sierraTimer += dt;
  if (sierraTimer >= 0.08) {
    sierraTimer = 0;
    sierraFrame = (sierraFrame + 1) % 2;
  }

  // Generación de obstáculos gobernada por dt
  tiempoSpawn += dt;
  if (tiempoSpawn >= proximoSpawn) {
    tiempoSpawn = 0;
    proximoSpawn = 1.0 + Math.random() * 0.95;
    obstaculos.push({
      x: canvas.width + 20,
      y: SUELO_Y - 56,
      ancho: 56,
      alto: 56
    });
  }

  // Mover obstáculos y comprobar colisiones
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    const obs = obstaculos[i];
    obs.x -= VELOCIDAD_JUEGO * dt;

    if (hayColision(jugador, obs)) {
      gameOver = true;
      if (Math.floor(puntaje) > mejorPuntaje) {
        mejorPuntaje = Math.floor(puntaje);
      }
    }

    if (obs.x + obs.ancho < 0) {
      obstaculos.splice(i, 1);
    }
  }

  // Puntaje proporcional al tiempo sobrevivido
  puntaje += 15 * dt;
}

// 7. RENDERIZADO EN CANVAS (CON TIJERAS MATEMÁTICAS drawImage)
function dibujar() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Mantener píxeles 100% nítidos al escalar
  ctx.imageSmoothingEnabled = false;

  // Cuadrícula sutil de fondo
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.07)';
  ctx.lineWidth = 1;
  for (let x = 0; x < canvas.width; x += 40) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, SUELO_Y); ctx.stroke();
  }

  // Suelo
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(0, SUELO_Y, canvas.width, canvas.height - SUELO_Y);
  ctx.fillStyle = '#38bdf8';
  ctx.fillRect(0, SUELO_Y, canvas.width, 3);

  // Dibujar obstáculos (Fila 3 del Sprite Sheet -> sy = 3 * 32 = 96)
  for (const obs of obstaculos) {
    const sx = sierraFrame * CELL_SIZE;
    const sy = 3 * CELL_SIZE;
    ctx.drawImage(
      spriteSheet,
      sx, sy, CELL_SIZE, CELL_SIZE,
      obs.x, obs.y, obs.ancho, obs.alto
    );
  }

  // Dibujar jugador recortando su celda exacta (sx, sy)
  const sx = jugador.frameActual * CELL_SIZE;
  const sy = jugador.filaEstado * CELL_SIZE;
  ctx.drawImage(
    spriteSheet,
    sx, sy, CELL_SIZE, CELL_SIZE,
    jugador.x, jugador.y, jugador.ancho, jugador.alto
  );

  // Marcador en pantalla
  ctx.fillStyle = '#94a3b8';
  ctx.font = 'bold 16px monospace';
  ctx.fillText(`HI ${String(mejorPuntaje).padStart(5, '0')}`, 24, 34);
  ctx.fillStyle = '#38bdf8';
  ctx.fillText(`SCORE ${String(Math.floor(puntaje)).padStart(5, '0')}`, 150, 34);

  if (gameOver) {
    ctx.fillStyle = 'rgba(2, 6, 23, 0.72)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#f8fafc';
    ctx.font = '900 36px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('¡IMPACTO DETECTADO!', canvas.width / 2, 180);

    ctx.fillStyle = '#38bdf8';
    ctx.font = '700 18px system-ui, sans-serif';
    ctx.fillText('Presiona ESPACIO o haz CLIC para volver a correr', canvas.width / 2, 222);
    ctx.textAlign = 'left';
  }
}

// 8. BUCLE PRINCIPAL CON requestAnimationFrame
function buclePrincipal(timestamp) {
  if (!ultimoTiempo) ultimoTiempo = timestamp;
  let dt = (timestamp - ultimoTiempo) / 1000;
  ultimoTiempo = timestamp;

  // Escudo anti-saltos si el usuario cambia de pestaña
  dt = Math.min(dt, 0.1);

  actualizar(dt);
  dibujar();

  requestAnimationFrame(buclePrincipal);
}

requestAnimationFrame(buclePrincipal);
