/**
 * ============================================================================
 * CÓDIGO ARCADE — EPISODIO #04
 * Tema: Sistema de Niveles, Progresión de Dificultad y Nuevos Obstáculos
 * Estudio: psy531 games | Serie: De Cero a Videojuego en HTML5 Canvas y JS
 * ============================================================================
 */

// 1. CONFIGURACIÓN DEL LIENZO Y CONTEXTO 2D
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const container = document.getElementById('gameContainer');

// Desactivamos el suavizado para conservar estética Pixel Art pura
ctx.imageSmoothingEnabled = false;

// 2. SINTETIZADOR RETRO 8-BIT CON WEB AUDIO API (Cero archivos .mp3 externos)
const AudioCtx = window.AudioContext || window.webkitAudioContext;
let audioCtx = null;

/**
 * Genera un efecto de sonido procedural deslizando la frecuencia.
 * @param {number} freqInicio - Frecuencia inicial en Hz
 * @param {number} freqFin - Frecuencia final en Hz
 * @param {number} duracion - Duración en segundos
 * @param {string} tipo - Forma de onda: 'square', 'triangle', 'sawtooth'
 * @param {number} volumen - Ganancia inicial (0.0 a 1.0)
 */
function tocarSonido(freqInicio, freqFin, duracion, tipo = 'square', volumen = 0.12) {
  if (!audioCtx) audioCtx = new AudioCtx();
  if (audioCtx.state === 'suspended') audioCtx.resume();

  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();

  osc.type = tipo;
  osc.frequency.setValueAtTime(freqInicio, audioCtx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqFin), audioCtx.currentTime + duracion);

  gain.gain.setValueAtTime(volumen, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duracion);

  osc.connect(gain);
  gain.connect(audioCtx.destination);

  osc.start();
  osc.stop(audioCtx.currentTime + duracion);
}

/**
 * Dispara un arpegio ascendente de 3 notas al subir de nivel.
 */
function sonidoLevelUp() {
  const notas = [523.25, 659.25, 783.99]; // Do5 -> Mi5 -> Sol5
  notas.forEach((freq, indice) => {
    setTimeout(() => {
      tocarSonido(freq, freq * 1.04, 0.12, 'triangle', 0.16);
    }, indice * 80);
  });
}

// 3. CARGA DEL SPRITESHEET OFICIAL (128x128 px dividido en celdas de 32x32 px)
// Fila 0: Idle [0], Game Over [1]
// Fila 1: Correr [0..3]
// Fila 2: Saltar [0], Caer [1]
// Fila 3: Sierra eléctrica giratoria [0..1]
const spriteSheet = new Image();
spriteSheet.src = 'spritesheet.png';
let spriteCargado = false;
spriteSheet.onload = () => { spriteCargado = true; };

// 4. PALETAS DE ATMÓSFERA VISUAL POR NIVEL
// Cada nivel cambia el ambiente del escenario para reforzar la sensación de avance
const PALETAS_NIVEL = [
  { cielo: '#0f172a', rejilla: '#1e293b', suelo: '#1e293b', bordeSuelo: '#38bdf8' }, // Nivel 1: Azul Noche
  { cielo: '#1e1b4b', rejilla: '#312e81', suelo: '#2e1065', bordeSuelo: '#818cf8' }, // Nivel 2: Índigo Profundo
  { cielo: '#2a0f1d', rejilla: '#4c0519', suelo: '#3b0764', bordeSuelo: '#f43f5e' }, // Nivel 3: Carmesí Oscuro
  { cielo: '#062c22', rejilla: '#064e3b', suelo: '#022c22', bordeSuelo: '#34d399' }  // Nivel 4+: Esmeralda Nocturno
];

// 5. CONSTANTES FÍSICAS Y VARIABLES DE ESTADO GLOBAL
const SUELO_Y = 300;
const GRAVEDAD = 1800;      // px/s²
const FUERZA_SALTO = -620;  // px/s hacia arriba

let estado = 'INICIO';      // 'INICIO' | 'JUGANDO' | 'GAMEOVER'
let puntuacion = 0;
let mejorPuntuacion = Number(localStorage.getItem('ca_ep04_best') || 0);

// Variables de progresión (Novedad Ep. 04)
let nivel = 1;
let nivelAnterior = 1;
let velocidadJuego = 320;   // Velocidad inicial en px/s
let bannerNivelTimer = 0;   // Temporizador en segundos para mostrar "¡NIVEL X!"

// Variables de Game Feel / Juice (Episodio #03)
let shakeTiempo = 0;
let shakeDuracionMax = 0.25;
let shakeFuerzaMax = 10;
let flashImpacto = 0;
const particulas = [];

// Entidad del Jugador
const jugador = {
  x: 110,
  y: SUELO_Y - 32,
  w: 32,
  h: 32,
  velY: 0,
  enSuelo: true,
  coyoteTimer: 0,           // Margen de gracia tras abandonar el suelo (0.10 s)
  jumpBufferTimer: 0,       // Memoria de pulsación anticipada antes de aterrizar (0.12 s)
  escalaX: 1,               // Deformación Squash & Stretch
  escalaY: 1,
  animTimer: 0,
  frame: 0
};

// Lista de obstáculos activos y control espacial del Spawner
const obstaculos = [];
let distanciaDesdeUltimo = 0;
let siguienteDistanciaMin = 360;

/**
 * Reinicia todas las variables para comenzar una nueva partida limpia.
 */
function iniciarPartida() {
  estado = 'JUGANDO';
  puntuacion = 0;
  nivel = 1;
  nivelAnterior = 1;
  velocidadJuego = 320;
  bannerNivelTimer = 0;

  obstaculos.length = 0;
  particulas.length = 0;
  distanciaDesdeUltimo = 0;
  siguienteDistanciaMin = 350;

  jugador.y = SUELO_Y - jugador.h;
  jugador.velY = 0;
  jugador.enSuelo = true;
  jugador.escalaX = 1;
  jugador.escalaY = 1;

  tocarSonido(260, 520, 0.14, 'square', 0.12);
}

/**
 * Crea partículas pixeladas con gravedad propia.
 */
function emitirParticulas(x, y, cantidad, color) {
  for (let i = 0; i < cantidad; i++) {
    particulas.push({
      x,
      y,
      vx: (Math.random() - 0.5) * 260,
      vy: -Math.random() * 220 - 40,
      vida: 0.35 + Math.random() * 0.25,
      vidaMax: 0.6,
      size: 3 + Math.floor(Math.random() * 4),
      gravedad: 520,
      color
    });
  }
}

// 6. ENTRADA DE USUARIO (TECLADO + RATÓN / TÁCTIL)
function presionarSalto() {
  if (estado !== 'JUGANDO') {
    iniciarPartida();
    return;
  }
  // Activamos el Jump Buffer para que el salto responda incluso si pulsas un instante antes de tocar el suelo
  jugador.jumpBufferTimer = 0.12;
}

function soltarSalto() {
  // Jump Cut: si sueltas la tecla mientras subes, recortamos la velocidad vertical para permitir saltos cortos
  if (estado === 'JUGANDO' && jugador.velY < -140) {
    jugador.velY *= 0.5;
  }
}

window.addEventListener('keydown', (e) => {
  if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
    e.preventDefault();
    if (!e.repeat) presionarSalto();
  }
});

window.addEventListener('keyup', (e) => {
  if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
    soltarSalto();
  }
});

canvas.addEventListener('pointerdown', (e) => { e.preventDefault(); presionarSalto(); });
canvas.addEventListener('pointerup', (e) => { e.preventDefault(); soltarSalto(); });

// 7. SPAWNER DE OBSTÁCULOS VARIADOS (3 ARQUETIPOS)
/**
 * Genera un obstáculo acorde al nivel desbloqueado:
 * - Nivel 1+: 'simple' -> 1 sierra en el suelo (32x32 px)
 * - Nivel 2+: 'doble'  -> 2 sierras juntas en el suelo (64x32 px)
 * - Nivel 3+: 'aerea'  -> 1 sierra suspendida dejando 44 px libres debajo para pasar sin saltar
 */
function generarObstaculo(nivelActual) {
  const disponibles = ['simple'];
  if (nivelActual >= 2) disponibles.push('doble');
  if (nivelActual >= 3) disponibles.push('aerea');

  const tipoElegido = disponibles[Math.floor(Math.random() * disponibles.length)];

  if (tipoElegido === 'simple') {
    obstaculos.push({ tipo: 'simple', x: canvas.width + 20, y: SUELO_Y - 32, w: 32, h: 32 });
  } else if (tipoElegido === 'doble') {
    obstaculos.push({ tipo: 'doble', x: canvas.width + 20, y: SUELO_Y - 32, w: 64, h: 32 });
  } else {
    // Altura SUELO_Y - 76: como la sierra mide 32 px de alto, queda un hueco de 44 px hasta el suelo
    obstaculos.push({ tipo: 'aerea', x: canvas.width + 20, y: SUELO_Y - 76, w: 32, h: 32 });
  }
}

/**
 * Detección de colisiones rectangulares (AABB) con un margen de perdón de 4 px.
 */
function colisionAABB(a, b) {
  const margen = 4;
  return (
    a.x + margen < b.x + b.w - margen &&
    a.x + a.w - margen > b.x + margen &&
    a.y + margen < b.y + b.h - margen &&
    a.y + a.h - margen > b.y + margen
  );
}

// 8. BUCLE DE ACTUALIZACIÓN LÓGICA (INDEPENDIENTE DE LOS FPS CON DELTA TIME)
let ultimoTiempo = performance.now();

function update(dt) {
  // Actualizar partículas en bucle inverso seguro
  for (let i = particulas.length - 1; i >= 0; i--) {
    const p = particulas[i];
    p.vida -= dt;
    if (p.vida <= 0) {
      particulas.splice(i, 1);
      continue;
    }
    p.vy += p.gravedad * dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
  }

  // Decaimiento del Screen Shake en el contenedor HTML
  if (shakeTiempo > 0) {
    shakeTiempo = Math.max(0, shakeTiempo - dt);
    const mag = (shakeTiempo / shakeDuracionMax) * shakeFuerzaMax;
    container.style.transform = `translate(${(Math.random() - 0.5) * mag}px, ${(Math.random() - 0.5) * mag}px)`;
  } else {
    container.style.transform = 'translate(0px, 0px)';
  }

  if (flashImpacto > 0) flashImpacto = Math.max(0, flashImpacto - dt * 3);
  if (bannerNivelTimer > 0) bannerNivelTimer = Math.max(0, bannerNivelTimer - dt);

  if (estado !== 'JUGANDO') return;

  // --- A. PROGRESIÓN DE NIVEL Y CURVA DE VELOCIDAD ---
  puntuacion += dt * 12; // 12 puntos por segundo de supervivencia
  nivel = Math.floor(puntuacion / 100) + 1;

  // Aceleramos +35 px/s por nivel, pero fijamos un techo máximo de 680 px/s para que el salto siempre sea posible
  velocidadJuego = Math.min(680, 320 + (nivel - 1) * 35);

  // Detectar subida de nivel
  if (nivel > nivelAnterior) {
    nivelAnterior = nivel;
    bannerNivelTimer = 1.5; // Mostrar alerta durante 1.5 segundos
    sonidoLevelUp();
    emitirParticulas(jugador.x + 16, jugador.y + 16, 18, '#facc15');
  }

  // --- B. FÍSICA DEL JUGADOR ---
  if (jugador.enSuelo) {
    jugador.coyoteTimer = 0.10;
  } else {
    jugador.coyoteTimer = Math.max(0, jugador.coyoteTimer - dt);
  }

  if (jugador.jumpBufferTimer > 0) jugador.jumpBufferTimer -= dt;

  // Ejecutar salto si hay buffer activo y Coyote Time disponible
  if (jugador.jumpBufferTimer > 0 && jugador.coyoteTimer > 0) {
    jugador.velY = FUERZA_SALTO;
    jugador.enSuelo = false;
    jugador.coyoteTimer = 0;
    jugador.jumpBufferTimer = 0;
    jugador.escalaX = 0.72;
    jugador.escalaY = 1.32;
    emitirParticulas(jugador.x + 16, SUELO_Y, 8, '#38bdf8');
    tocarSonido(220, 580, 0.13, 'square', 0.12);
  }

  const estabaEnAire = !jugador.enSuelo;
  jugador.velY += GRAVEDAD * dt;
  jugador.y += jugador.velY * dt;

  // Aterrizaje en el suelo
  if (jugador.y >= SUELO_Y - jugador.h) {
    jugador.y = SUELO_Y - jugador.h;
    jugador.velY = 0;
    jugador.enSuelo = true;
    if (estabaEnAire) {
      jugador.escalaX = 1.3;
      jugador.escalaY = 0.75;
      emitirParticulas(jugador.x + 16, SUELO_Y, 6, '#94a3b8');
      tocarSonido(150, 70, 0.08, 'triangle', 0.10);
    }
  }

  // Recuperación elástica hacia escala (1, 1)
  jugador.escalaX += (1 - jugador.escalaX) * Math.min(1, dt * 14);
  jugador.escalaY += (1 - jugador.escalaY) * Math.min(1, dt * 14);

  // Velocidad de animación de carrera proporcional a la velocidad del juego
  jugador.animTimer += dt * (velocidadJuego / 320);
  if (jugador.animTimer >= 0.09) {
    jugador.animTimer = 0;
    jugador.frame = (jugador.frame + 1) % 4;
  }

  // --- C. SPAWNER INTELIGENTE POR DISTANCIA SEGURA ---
  distanciaDesdeUltimo += velocidadJuego * dt;
  if (distanciaDesdeUltimo >= siguienteDistanciaMin) {
    generarObstaculo(nivel);
    distanciaDesdeUltimo = 0;
    // Garantizamos al menos 0.85 segundos de margen limpio + variación aleatoria
    siguienteDistanciaMin = velocidadJuego * 0.85 + Math.random() * 180;
  }

  // --- D. ACTUALIZAR OBSTÁCULOS Y COMPROBAR COLISIONES ---
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    const obs = obstaculos[i];
    obs.x -= velocidadJuego * dt;

    if (colisionAABB(jugador, obs)) {
      estado = 'GAMEOVER';
      shakeTiempo = shakeDuracionMax;
      flashImpacto = 0.65;
      emitirParticulas(jugador.x + 16, jugador.y + 16, 26, '#ef4444');
      tocarSonido(190, 45, 0.35, 'sawtooth', 0.18);

      if (Math.floor(puntuacion) > mejorPuntuacion) {
        mejorPuntuacion = Math.floor(puntuacion);
        localStorage.setItem('ca_ep04_best', mejorPuntuacion);
      }
    }

    // Eliminar obstáculos que salieron por la izquierda
    if (obs.x + obs.w < -40) {
      obstaculos.splice(i, 1);
    }
  }
}

// 9. RENDERIZADO EN EL CANVAS
function draw() {
  const pal = PALETAS_NIVEL[Math.min(PALETAS_NIVEL.length - 1, nivel - 1)];

  ctx.save();
  if (shakeTiempo > 0) {
    const mag = (shakeTiempo / shakeDuracionMax) * 6;
    ctx.translate((Math.random() - 0.5) * mag, (Math.random() - 0.5) * mag);
  }

  // Fondo según el nivel actual
  ctx.fillStyle = pal.cielo;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Rejilla retro con paralaje
  ctx.strokeStyle = pal.rejilla;
  ctx.lineWidth = 1;
  const offsetGrid = (puntuacion * 4) % 40;
  for (let gx = -offsetGrid; gx < canvas.width; gx += 40) {
    ctx.beginPath();
    ctx.moveTo(gx, 0);
    ctx.lineTo(gx, SUELO_Y);
    ctx.stroke();
  }

  // Plataforma del suelo
  ctx.fillStyle = pal.suelo;
  ctx.fillRect(0, SUELO_Y, canvas.width, canvas.height - SUELO_Y);
  ctx.fillStyle = pal.bordeSuelo;
  ctx.fillRect(0, SUELO_Y, canvas.width, 4);

  // Dibujar obstáculos (1 o 2 celdas según si es simple/aérea o doble)
  const sawFrame = Math.floor(performance.now() / 70) % 2;
  obstaculos.forEach((obs) => {
    const numSierras = obs.tipo === 'doble' ? 2 : 1;
    for (let c = 0; c < numSierras; c++) {
      const drawX = obs.x + c * 32;
      if (spriteCargado) {
        ctx.drawImage(spriteSheet, sawFrame * 32, 96, 32, 32, drawX, obs.y, 32, 32);
      } else {
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(drawX + 4, obs.y + 4, 24, 24);
      }
    }
  });

  // Dibujar jugador con Squash & Stretch anclado a sus pies
  ctx.save();
  ctx.translate(jugador.x + jugador.w / 2, jugador.y + jugador.h);
  ctx.scale(jugador.escalaX, jugador.escalaY);
  if (spriteCargado) {
    let fila = 1;
    let col = jugador.frame;
    if (estado !== 'JUGANDO') {
      fila = 0;
      col = estado === 'GAMEOVER' ? 1 : 0;
    } else if (!jugador.enSuelo) {
      fila = 2;
      col = jugador.velY < 0 ? 0 : 1;
    }
    ctx.drawImage(spriteSheet, col * 32, fila * 32, 32, 32, -16, -32, 32, 32);
  } else {
    ctx.fillStyle = '#38bdf8';
    ctx.fillRect(-16, -32, 32, 32);
  }
  ctx.restore();

  // Dibujar partículas
  particulas.forEach((p) => {
    ctx.globalAlpha = Math.max(0, p.vida / p.vidaMax);
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x, p.y, p.size, p.size);
  });
  ctx.globalAlpha = 1;

  // HUD de Puntuación, Nivel y Récord
  ctx.fillStyle = '#f8fafc';
  ctx.font = 'bold 18px monospace';
  ctx.textAlign = 'left';
  ctx.fillText(`PUNTOS: ${String(Math.floor(puntuacion)).padStart(4, '0')}`, 20, 32);

  ctx.fillStyle = '#38bdf8';
  ctx.fillText(`NIVEL ${nivel} (${Math.round(velocidadJuego)} px/s)`, 220, 32);

  ctx.textAlign = 'right';
  ctx.fillStyle = '#94a3b8';
  ctx.fillText(`RÉCORD: ${String(mejorPuntuacion).padStart(4, '0')}`, canvas.width - 20, 32);

  // Banner animado de subida de nivel ("¡NIVEL X!")
  if (bannerNivelTimer > 0) {
    const progreso = 1 - bannerNivelTimer / 1.5;
    const scale = 1 + Math.sin(Math.min(1, progreso * 3) * Math.PI) * 0.35;
    ctx.save();
    ctx.translate(canvas.width / 2, 120);
    ctx.scale(scale, scale);
    ctx.globalAlpha = Math.min(1, bannerNivelTimer * 2);
    ctx.fillStyle = '#facc15';
    ctx.font = 'bold 38px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`¡NIVEL ${nivel}!`, 0, 0);
    ctx.restore();
  }

  // Overlay de Inicio o Game Over
  if (estado === 'INICIO' || estado === 'GAMEOVER') {
    ctx.fillStyle = 'rgba(2, 6, 23, 0.72)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.textAlign = 'center';
    ctx.fillStyle = estado === 'GAMEOVER' ? '#ef4444' : '#38bdf8';
    ctx.font = 'bold 34px monospace';
    ctx.fillText(estado === 'GAMEOVER' ? 'GAME OVER' : 'NIVELES Y OBSTÁCULOS', canvas.width / 2, 150);

    ctx.fillStyle = '#f8fafc';
    ctx.font = '18px monospace';
    ctx.fillText('Pulsa ESPACIO o haz CLIC para jugar', canvas.width / 2, 195);
  }

  // Flash rojo de impacto
  if (flashImpacto > 0) {
    ctx.fillStyle = `rgba(239, 68, 68, ${flashImpacto})`;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  ctx.restore();
}

// 10. ARRANQUE DEL GAME LOOP
function loop(now) {
  const dt = Math.min(0.05, (now - ultimoTiempo) / 1000);
  ultimoTiempo = now;
  update(dt);
  draw();
  requestAnimationFrame(loop);
}

requestAnimationFrame(loop);
