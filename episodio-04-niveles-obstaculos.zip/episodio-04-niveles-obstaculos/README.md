# Código Arcade — Episodio #04: Niveles, Dificultad Progresiva y Nuevos Obstáculos

Código fuente oficial y comentado paso a paso de la serie **"De Cero a Videojuego en HTML5 Canvas y JavaScript"** por **psy531 games**.

## Contenido del Paquete
- `index.html`: Estructura base con el lienzo `<canvas width="800" height="360">`.
- `style.css`: Diseño arcade oscuro con `image-rendering: pixelated`.
- `game.js`: Lógica completa comentada (niveles cada 100 pts, tope de velocidad `680 px/s`, 3 arquetipos de obstáculos, spawner por distancia segura `0.85 s`, paletas por nivel y arpegio Web Audio API).
- `spritesheet.png`: Hoja oficial `128×128 px` con celdas de `32×32 px`.

## Cómo Ejecutar
Abre `index.html` directamente en cualquier navegador moderno o sírvelo con Live Server / Vite.
