// ============================================================================
// 1. INICIALIZACIÓN DEL LIENZO (CANVAS)
// ============================================================================
// Obtenemos la referencia al elemento <canvas> del HTML y su contexto 2D para dibujar
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

// ============================================================================
// 2. CONSTANTES Y ENTIDADES DEL JUEGO
// ============================================================================
const GROUND_Y = 360;   // Altura en píxeles donde empieza el suelo (eje Y)
const GRAVITY = 0.65;   // Fuerza constante que empuja al jugador hacia abajo

// Objeto que almacena la posición, tamaño y física del jugador
const player = {
  x: 110,               // Posición horizontal fija
  y: GROUND_Y - 48,     // Posición vertical inicial (apoyado justo sobre el suelo)
  w: 44,                // Ancho del jugador en píxeles
  h: 48,                // Alto del jugador en píxeles
  vy: 0,                // Velocidad vertical actual (negativa = sube, positiva = cae)
  jumpForce: -13.5,     // Impulso inicial hacia arriba al saltar
  grounded: true        // Bandera que evita saltar en el aire (evita saltos infinitos)
};

// Objeto que representa el obstáculo enemigo que avanza desde la derecha
const obstacle = {
  x: canvas.width + 60, // Empieza fuera de pantalla por el borde derecho
  y: GROUND_Y - 42,     // Apoyado sobre el mismo nivel de suelo
  w: 36,                // Ancho del obstáculo
  h: 42,                // Alto del obstáculo
  speed: 6.5            // Velocidad horizontal en píxeles por fotograma
};

// Variables de estado de la partida
let score = 0;          // Puntuación actual del jugador
let gameOver = false;   // Controla si la partida terminó por choque

// ============================================================================
// 3. MECÁNICAS DE ACCIÓN Y CONTROLES
// ============================================================================
// Ejecuta el salto si está en el suelo, o reinicia el juego si hubo Game Over
function jump() {
  if (gameOver) {
    resetGame();
    return;
  }

  // Solo permitimos saltar si el jugador está tocando el suelo
  if (player.grounded) {
    player.vy = player.jumpForce; // Aplicamos velocidad negativa para subir
    player.grounded = false;      // Marcamos que ahora está en el aire
  }
}

// Restaura todas las variables a sus valores iniciales para volver a jugar
function resetGame() {
  player.y = GROUND_Y - player.h;
  player.vy = 0;
  player.grounded = true;
  obstacle.x = canvas.width + 60;
  obstacle.speed = 6.5;
  score = 0;
  gameOver = false;
}

// Escuchamos las teclas Espacio o Flecha Arriba en el teclado
window.addEventListener("keydown", (e) => {
  if (e.code === "Space" || e.code === "ArrowUp") {
    e.preventDefault(); // Evita que la barra espaciadora haga scroll en la página
    jump();
  }
});

// Soporte táctil y clic de ratón para jugar también en dispositivos móviles
canvas.addEventListener("pointerdown", jump);

// ============================================================================
// 4. DETECCIÓN DE COLISIONES (ALGORITMO AABB)
// ============================================================================
// Comprueba si dos rectángulos (a y b) se están superponiendo en los ejes X e Y
function checkCollision(a, b) {
  return (
    a.x < b.x + b.w &&  // El borde izquierdo de A está a la izquierda del borde derecho de B
    a.x + a.w > b.x &&  // El borde derecho de A está a la derecha del borde izquierdo de B
    a.y < b.y + b.h &&  // El borde superior de A está por encima del borde inferior de B
    a.y + a.h > b.y     // El borde inferior de A está por debajo del borde superior de B
  );
}

// ============================================================================
// 5. ACTUALIZACIÓN DE LÓGICA Y FÍSICA (UPDATE)
// ============================================================================
function update() {
  // Si el juego terminó, congelamos la simulación física
  if (gameOver) return;

  // --- Física vertical del jugador ---
  player.vy += GRAVITY;   // La gravedad acelera la caída en cada fotograma
  player.y += player.vy;  // Actualizamos la posición vertical según la velocidad

  // Límite del suelo: evita que el jugador atraviese el piso hacia el vacío
  if (player.y >= GROUND_Y - player.h) {
    player.y = GROUND_Y - player.h;
    player.vy = 0;
    player.grounded = true;
  }

  // --- Movimiento del obstáculo ---
  obstacle.x -= obstacle.speed; // Desplazamos el obstáculo hacia la izquierda

  // Si el obstáculo sale por el borde izquierdo, lo reciclamos y sumamos 1 punto
  if (obstacle.x + obstacle.w < 0) {
    obstacle.x = canvas.width + 40;
    score++;
    obstacle.speed += 0.25; // Aumentamos ligeramente la dificultad con cada punto
  }

  // --- Verificación de impacto ---
  if (checkCollision(player, obstacle)) {
    gameOver = true;
  }
}

// ============================================================================
// 6. RENDERIZADO EN PANTALLA (DRAW)
// ============================================================================
function draw() {
  // 1. Limpiamos todo el lienzo antes de dibujar el nuevo fotograma
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // 2. Dibujamos el suelo
  ctx.fillStyle = "#cbd5e1";
  ctx.fillRect(0, GROUND_Y, canvas.width, canvas.height - GROUND_Y);

  // 3. Dibujamos al jugador (rectángulo verde)
  ctx.fillStyle = "#10b981";
  ctx.fillRect(player.x, player.y, player.w, player.h);

  // 4. Dibujamos el obstáculo (rectángulo rojo)
  ctx.fillStyle = "#ef4444";
  ctx.fillRect(obstacle.x, obstacle.y, obstacle.w, obstacle.h);

  // 5. Dibujamos el marcador de puntuación en la esquina superior izquierda
  ctx.fillStyle = "#0f172a";
  ctx.font = "bold 24px monospace";
  ctx.fillText(`PUNTOS: ${score}`, 28, 44);

  // 6. Si hay Game Over, superponemos una pantalla semitransparente de reinicio
  if (gameOver) {
    ctx.fillStyle = "rgba(15, 23, 42, 0.78)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "center";
    ctx.font = "bold 38px sans-serif";
    ctx.fillText("GAME OVER", canvas.width / 2, 200);

    ctx.font = "20px sans-serif";
    ctx.fillText("Presiona ESPACIO o haz clic para reiniciar", canvas.width / 2, 245);
    ctx.textAlign = "left"; // Restauramos la alineación por defecto
  }
}

// ============================================================================
// 7. EL BUCLE PRINCIPAL (GAME LOOP A 60 FPS)
// ============================================================================
function loop() {
  update();                       // Paso 1: Calculamos movimientos y colisiones
  draw();                         // Paso 2: Dibujamos el resultado en pantalla
  requestAnimationFrame(loop);    // Paso 3: Solicitamos al navegador el siguiente cuadro
}

// Arrancamos el motor del juego
loop();
