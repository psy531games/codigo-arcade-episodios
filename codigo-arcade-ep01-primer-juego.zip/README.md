# 🎮 Episodio #01: Tu Primer Videojuego Web desde Cero (HTML, CSS y JS)

Código fuente oficial y comentado del primer episodio de **Código Arcade**.

## 🚀 Cómo ejecutarlo en tu computadora
1. Descomprime esta carpeta en cualquier lugar de tu equipo.
2. Haz doble clic sobre el archivo **`index.html`**.
3. ¡Listo! Se abrirá directamente en tu navegador sin instalar motores ni dependencias.

## 🕹️ Controles
- **Saltar / Reiniciar:** `Espacio`, `Flecha Arriba` o `Clic / Toque en pantalla`.

## 🏆 Retos propuestos al final del video
Abre `game.js` en tu editor favorito y prueba estas 3 modificaciones:
1. **Gravedad lunar:** Cambia `GRAVITY = 0.65` por `0.35`.
2. **Modo turbo:** Aumenta el incremento de velocidad en `obstacle.speed += 0.5`.
3. **Doble salto:** Agrega un contador `jumps = 0` para permitir hasta 2 saltos antes de tocar el suelo.
