// ============================================================================
// CÓDIGO ARCADE — EPISODIO #03: GAME FEEL (JUICE)
// Incluye: Delta Time, Sprites 32x32, Coyote Time, Jump Buffer, Jump Cut,
// Partículas Procedurales, Squash & Stretch, Screen Shake y Web Audio API.
// ============================================================================

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const canvasFrame = document.getElementById('canvasFrame');

// 1. CARGA DEL SPRITE SHEET (128x128 px dividido en celdas de 32x32 px)
const spriteSheet = new Image();
spriteSheet.src = 'spritesheet.png';
const CELL = 32;

// 2. SINTETIZADOR RETRO 8-BIT (WEB AUDIO API — CERO ARCHIVOS MP3)
const AudioCtx = window.AudioContext || window.webkitAudioContext;
const audioCtx = new AudioCtx();

function tocarSonido(freqInicio, freqFin, duracion, tipo = 'square', volumen = 0.14) {
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  const ahora = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();

  osc.type = tipo;
  osc.frequency.setValueAtTime(freqInicio, ahora);
  osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqFin), ahora + duracion);

  gain.gain.setValueAtTime(volumen, ahora);
  gain.gain.exponentialRampToValueAtTime(0.001, ahora + duracion);

  osc.connect(gain);
  gain.connect(audioCtx.destination);

  osc.start(ahora);
  osc.stop(ahora + duracion);
}

// Efectos de sonido preconfigurados del episodio
const SFX = {
  salto: () => tocarSonido(180, 520, 0.12, 'square', 0.13),
  aterrizaje: () => tocarSonido(140, 55, 0.08, 'triangle', 0.16),
  choque: () => tocarSonido(160, 38, 0.32, 'sawtooth', 0.20),
  // RETO DEL EPISODIO: Descomenta o modifica esta función para personalizar la melodía cada 100 puntos
  puntos100: () => {
    tocarSonido(523.25, 523.25, 0.08, 'square', 0.12); // Nota Do5
    setTimeout(() => tocarSonido(659.25, 659.25, 0.14, 'square', 0.12), 85); // Nota Mi5
  }
};

// 3. CONSTANTES DE FÍSICA Y GAME FEEL
const GRAVEDAD = 2100;
const FUERZA_SALTO = -740;
const VELOCIDAD_MUNDO = 370;
const SUELO_Y = 295;

// 4. ESTADO DEL JUGADOR (Con Coyote Time, Jump Buffer y Squash & Stretch)
const jugador = {
  x: 100,
  y: SUELO_Y - 64,
  ancho: 64,
  alto: 64,
  velY: 0,
  enElSuelo: true,
  coyoteTimer: 0,     // Ventana de gracia tras dejar el suelo (0.10 s)
  jumpBufferTimer: 0, // Memoria de pulsación antes de tocar suelo (0.12 s)
  scaleX: 1,
  scaleY: 1,
  fila: 1,
  frame: 0,
  animTimer: 0
};

// 5. SISTEMA DE PARTÍCULAS Y SCREEN SHAKE
let particulas = [];
let obstaculos = [];
let spawnTimer = 0;
let nextSpawn = 1.25;
let sierraFrame = 0;
let sierraTimer = 0;

let shakeTiempo = 0;
let shakeDuracionMax = 0.45;
let shakeFuerzaMax = 26;
let flashAlpha = 0;

let puntaje = 0;
let mejorPuntaje = 0;
let ultimoHito100 = 0;
let gameOver = false;
let ultimoTiempo = 0;

function activarScreenShake(duracion, fuerza) {
  shakeTiempo = duracion;
  shakeDuracionMax = duracion;
  shakeFuerzaMax = fuerza;
}

function crearParticulas(x, y, cantidad, colores, velocidadMax, gravedadParticula = 480) {
  for (let i = 0; i < cantidad; i++) {
    const angulo = Math.random() * Math.PI * 2;
    const velocidad = 45 + Math.random() * velocidadMax;
    const vida = 0.35 + Math.random() * 0.35;
    particulas.push({
      x,
      y,
      vx: Math.cos(angulo) * velocidad,
      vy: Math.sin(angulo) * velocidad - 90,
      vida,
      vidaMax: vida,
      size: 5 + Math.random() * 6,
      gravedad: gravedadParticula,
      color: colores[Math.floor(Math.random() * colores.length)]
    });
  }
}

function reiniciarJuego() {
  jugador.y = SUELO_Y - jugador.alto;
  jugador.velY = 0;
  jugador.enElSuelo = true;
  jugador.coyoteTimer = 0;
  jugador.jumpBufferTimer = 0;
  jugador.scaleX = 1;
  jugador.scaleY = 1;
  jugador.fila = 1;
  jugador.frame = 0;

  obstaculos = [];
  particulas = [];
  spawnTimer = 0;
  nextSpawn = 1.2;
  shakeTiempo = 0;
  flashAlpha = 0;
  if (canvasFrame) canvasFrame.style.transform = 'translate(0px, 0px)';
  puntaje = 0;
  ultimoHito100 = 0;
  gameOver = false;
}

// 6. CONTROLES RESPONSIVOS (JUMP BUFFER + JUMP CUT)
function solicitarSalto() {
  if (audioCtx.state === 'suspended') audioCtx.resume();
  if (gameOver) {
    reiniciarJuego();
    return;
  }
  jugador.jumpBufferTimer = 0.12; // Guarda la orden durante 120 ms
}

function cortarSalto() {
  // Si suelta la tecla mientras sube, recorta la velocidad vertical a la mitad
  if (!gameOver && jugador.velY < 0) {
    jugador.velY *= 0.5;
  }
}

window.addEventListener('keydown', (e) => {
  if (e.repeat) return;
  if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
    e.preventDefault();
    solicitarSalto();
  } else if (e.code === 'KeyR' && gameOver) {
    reiniciarJuego();
  }
});

window.addEventListener('keyup', (e) => {
  if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
    cortarSalto();
  }
});

canvas.addEventListener('pointerdown', solicitarSalto);
canvas.addEventListener('pointerup', cortarSalto);

function hayColision(a, b) {
  const margen = 13;
  return (
    a.x + margen < b.x + b.ancho - margen &&
    a.x + a.ancho - margen > b.x + margen &&
    a.y + margen < b.y + b.alto - margen &&
    a.y + a.alto - margen > b.y + margen
  );
}

// 7. BUCLE DE ACTUALIZACIÓN (UPDATE)
function update(dt) {
  if (shakeTiempo > 0) {
    shakeTiempo = Math.max(0, shakeTiempo - dt);
  }
  if (flashAlpha > 0) {
    flashAlpha = Math.max(0, flashAlpha - dt * 2.8);
  }

  // Actualizar partículas (recorrido inverso seguro)
  for (let i = particulas.length - 1; i >= 0; i--) {
    const p = particulas[i];
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vy += p.gravedad * dt;
    p.vida -= dt;
    if (p.vida <= 0) {
      particulas.splice(i, 1);
    }
  }

  if (gameOver) {
    jugador.fila = 0;
    jugador.animTimer += dt;
    if (jugador.animTimer >= 0.25) {
      jugador.animTimer = 0;
      jugador.frame = (jugador.frame + 1) % 2;
    }
    return;
  }

  // Temporizadores de Coyote Time y Jump Buffer
  if (jugador.enElSuelo) {
    jugador.coyoteTimer = 0.10;
  } else {
    jugador.coyoteTimer = Math.max(0, jugador.coyoteTimer - dt);
  }

  if (jugador.jumpBufferTimer > 0) {
    jugador.jumpBufferTimer = Math.max(0, jugador.jumpBufferTimer - dt);
  }

  // Ejecución del salto combinado
  if (jugador.jumpBufferTimer > 0 && jugador.coyoteTimer > 0) {
    jugador.velY = FUERZA_SALTO;
    jugador.enElSuelo = false;
    jugador.coyoteTimer = 0;
    jugador.jumpBufferTimer = 0;
    jugador.scaleX = 0.82; // Estiramiento al despegar
    jugador.scaleY = 1.22;
    SFX.salto();
    crearParticulas(jugador.x + jugador.ancho / 2, SUELO_Y, 10, ['#38bdf8', '#e2e8f0'], 140);
  }

  // Gravedad y detección de aterrizaje
  const estabaEnElAire = !jugador.enElSuelo;
  jugador.velY += GRAVEDAD * dt;
  jugador.y += jugador.velY * dt;

  if (jugador.y >= SUELO_Y - jugador.alto) {
    jugador.y = SUELO_Y - jugador.alto;
    jugador.velY = 0;
    jugador.enElSuelo = true;

    if (estabaEnElAire) {
      jugador.scaleX = 1.26; // Achatamiento elástico al aterrizar
      jugador.scaleY = 0.76;
      SFX.aterrizaje();
      activarScreenShake(0.12, 8); // Micro-vibración táctil al aterrizar
      crearParticulas(jugador.x + jugador.ancho / 2, SUELO_Y, 12, ['#94a3b8', '#38bdf8'], 160);
    }
  }

  // Recuperación suave de escala (Squash & Stretch -> 1.0)
  jugador.scaleX += (1 - jugador.scaleX) * Math.min(1, dt * 16);
  jugador.scaleY += (1 - jugador.scaleY) * Math.min(1, dt * 16);

  // Selección de fotograma del Sprite Sheet
  if (!jugador.enElSuelo) {
    jugador.fila = 2;
    jugador.frame = jugador.velY < 0 ? 0 : 1;
  } else {
    jugador.fila = 1;
    jugador.animTimer += dt;
    if (jugador.animTimer >= 0.085) {
      jugador.animTimer = 0;
      jugador.frame = (jugador.frame + 1) % 4;
      // Polvo sutil al correr
      crearParticulas(jugador.x + 14, SUELO_Y - 2, 1, ['#64748b', '#94a3b8'], 65, 120);
    }
  }

  // Animación de sierra
  sierraTimer += dt;
  if (sierraTimer >= 0.08) {
    sierraTimer = 0;
    sierraFrame = (sierraFrame + 1) % 2;
  }

  // Generación y movimiento de obstáculos
  spawnTimer += dt;
  if (spawnTimer >= nextSpawn) {
    spawnTimer = 0;
    nextSpawn = 0.95 + Math.random() * 0.85;
    obstaculos.push({
      x: canvas.width + 20,
      y: SUELO_Y - 54,
      ancho: 54,
      alto: 54
    });
  }

  for (let i = obstaculos.length - 1; i >= 0; i--) {
    const o = obstaculos[i];
    o.x -= VELOCIDAD_MUNDO * dt;

    if (hayColision(jugador, o)) {
      gameOver = true;
      SFX.choque();
      activarScreenShake(0.45, 28); // Vibración contundente de impacto
      flashAlpha = 0.45;
      crearParticulas(
        jugador.x + jugador.ancho / 2,
        jugador.y + jugador.alto / 2,
        34,
        ['#ef4444', '#f59e0b', '#fde047', '#ffffff'],
        340
      );
      if (Math.floor(puntaje) > mejorPuntaje) {
        mejorPuntaje = Math.floor(puntaje);
      }
    }

    if (o.x + o.ancho < 0) {
      obstaculos.splice(i, 1);
    }
  }

  // Puntaje y melodía cada 100 puntos
  puntaje += 18 * dt;
  const hitoActual = Math.floor(puntaje / 100);
  if (hitoActual > ultimoHito100) {
    ultimoHito100 = hitoActual;
    SFX.puntos100();
  }
}

// 8. RENDERIZADO EN CANVAS (DRAW)
function draw() {
  ctx.save();
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.imageSmoothingEnabled = false;

  // Aplicar Screen Shake tanto en el contexto del Canvas como en el marco contenedor
  if (shakeTiempo > 0) {
    const intensidad = (shakeTiempo / shakeDuracionMax) * shakeFuerzaMax;
    const dx = (Math.random() * 2 - 1) * intensidad;
    const dy = (Math.random() * 2 - 1) * intensidad;
    ctx.translate(dx, dy);
    if (canvasFrame) {
      canvasFrame.style.transform = `translate(${dx * 0.5}px, ${dy * 0.5}px)`;
    }
  } else if (canvasFrame) {
    canvasFrame.style.transform = 'translate(0px, 0px)';
  }

  // Cuadrícula de fondo
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.07)';
  ctx.lineWidth = 1;
  for (let x = 0; x < canvas.width; x += 40) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, SUELO_Y);
    ctx.stroke();
  }

  // Suelo
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(0, SUELO_Y, canvas.width, canvas.height - SUELO_Y);
  ctx.fillStyle = '#38bdf8';
  ctx.fillRect(0, SUELO_Y, canvas.width, 3);

  // Sierras eléctricas
  for (const o of obstaculos) {
    ctx.drawImage(spriteSheet, sierraFrame * CELL, 3 * CELL, CELL, CELL, o.x, o.y, o.ancho, o.alto);
  }

  // Jugador con deformación Squash & Stretch anclada a los pies
  const drawW = jugador.ancho * jugador.scaleX;
  const drawH = jugador.alto * jugador.scaleY;
  const drawX = jugador.x + (jugador.ancho - drawW) / 2;
  const drawY = jugador.y + (jugador.alto - drawH);

  ctx.drawImage(
    spriteSheet,
    jugador.frame * CELL,
    jugador.fila * CELL,
    CELL,
    CELL,
    drawX,
    drawY,
    drawW,
    drawH
  );

  // Partículas procedurales
  for (const p of particulas) {
    ctx.globalAlpha = Math.max(0, p.vida / p.vidaMax);
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x, p.y, p.size, p.size);
  }
  ctx.globalAlpha = 1;

  // Destello breve de impacto
  if (flashAlpha > 0) {
    ctx.fillStyle = `rgba(255, 255, 255, ${flashAlpha})`;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  // Marcador
  ctx.fillStyle = '#94a3b8';
  ctx.font = 'bold 15px monospace';
  ctx.fillText(`HI ${String(mejorPuntaje).padStart(5, '0')}`, 22, 32);
  ctx.fillStyle = '#38bdf8';
  ctx.fillText(`SCORE ${String(Math.floor(puntaje)).padStart(5, '0')}`, 140, 32);

  if (gameOver) {
    ctx.fillStyle = 'rgba(2, 6, 23, 0.72)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#f8fafc';
    ctx.font = '900 32px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('¡IMPACTO DETECTADO!', canvas.width / 2, 165);
    ctx.fillStyle = '#38bdf8';
    ctx.font = '700 17px system-ui, sans-serif';
    ctx.fillText('Haz CLIC o presiona ESPACIO para volver a correr', canvas.width / 2, 202);
    ctx.textAlign = 'left';
  }

  ctx.restore();
}

function loop(timestamp) {
  if (!ultimoTiempo) ultimoTiempo = timestamp;
  const dt = Math.min((timestamp - ultimoTiempo) / 1000, 0.1);
  ultimoTiempo = timestamp;

  update(dt);
  draw();
  requestAnimationFrame(loop);
}

requestAnimationFrame(loop);
