# Código Arcade — Episodio #03: Game Feel (Juice)

Proyecto completo y comentado del Episodio #03 del canal **Código Arcade**.

## Contenido del paquete
- `index.html`: Estructura base con `<canvas>` de `800×360 px`.
- `style.css`: Interfaz oscura estilo consola arcade y renderizado nítido (`image-rendering: pixelated`).
- `game.js`: Lógica completa con Delta Time, Coyote Time, Jump Buffer, Jump Cut, partículas procedurales, Squash & Stretch, Screen Shake (en canvas y contenedor) y sintetizador retro de 8 bits con Web Audio API.
- `spritesheet.png`: Hoja de sprites `128×128 px` (celdas de `32×32 px`).
